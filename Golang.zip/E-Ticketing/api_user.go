package main

import (
	"database/sql"
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"time"

	_ "github.com/lib/pq"
)

const (
	host     = "localhost"
	port     = 5432
	user     = "postgres"
	password = "3k0l0k4s1*123#"
	dbname   = "e-ticketing_mkp"
)

var db *sql.DB

type Customer struct {
	Name string `json:"nama"`
	Kota string `json:"nama_kota"`
}

type Bioskop struct {
	ID          int    `json:"id"`
	NamaBioskop string `json:"nama_bioskop"`
}

type Film struct {
	ID        int    `json:"id"`
	JudulFilm string `json:"judul_film"`
}

type Theater struct {
	ID      int    `json:"id"`
	Theater string `json:"theater"`
}

type Seat struct {
	ID   int    `json:"id"`
	Seat string `json:"seat"`
}

func main() {
	// Database
	psqlconn := fmt.Sprintf("host=%s port=%d user=%s password=%s dbname=%s sslmode=disable", host, port, user, password, dbname)
	var err error
	db, err = sql.Open("postgres", psqlconn)
	if err != nil {
		log.Fatal(err)
	}
	defer db.Close()

	// Route API
	http.HandleFunc("/login", loginHandler)
	http.HandleFunc("/bioskops", getBioskopsHandler)
	http.HandleFunc("/films", getFilmsHandler)
	http.HandleFunc("/theaters", getTheatersHandler)
	http.HandleFunc("/seats", getSeatsHandler)
	http.HandleFunc("/insert_ticket", insertTicketHandler)
	log.Fatal(http.ListenAndServe(":8080", nil))
}

func loginHandler(w http.ResponseWriter, r *http.Request) {
	var requestBody struct {
		Username string `json:"username"`
		Password string `json:"password"`
	}
	if err := json.NewDecoder(r.Body).Decode(&requestBody); err != nil {
		http.Error(w, "Invalid request body", http.StatusBadRequest)
		return
	}

	customer, err := authenticateCustomer(requestBody.Username, requestBody.Password)
	if err != nil {
		http.Error(w, err.Error(), http.StatusUnauthorized)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(customer)
}

func getBioskopsHandler(w http.ResponseWriter, r *http.Request) {
	// Ambil bioskop tergantung nama kota
	customerKota := r.Header.Get("X-Customer-Kota")
	bioskops, err := getBioskops(customerKota)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(bioskops)
}

func getFilmsHandler(w http.ResponseWriter, r *http.Request) {
	// Ambil List dari Film
	bioskopID := r.URL.Query().Get("bioskop_id")
	films, err := getFilms(bioskopID)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(films)
}

func getTheatersHandler(w http.ResponseWriter, r *http.Request) {
	// pilih Theater
	filmID := r.URL.Query().Get("film_id")
	theaters, err := getTheaters(filmID)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(theaters)
}

func getSeatsHandler(w http.ResponseWriter, r *http.Request) {
	// Pilih tempat duduk
	theaterID := r.URL.Query().Get("theater_id")
	seats, err := getSeats(theaterID)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(seats)
}

func authenticateCustomer(username, password string) (*Customer, error) {
	var customer Customer
	err := db.QueryRow(`
		SELECT customer.nama, kota.nama_kota
		FROM customer 
		JOIN kota ON customer.id_kota = kota.id_kota
		WHERE customer.nama = $1 AND customer.password = $2
	`, username, password).Scan(&customer.Name, &customer.Kota)
	if err == sql.ErrNoRows {
		return nil, fmt.Errorf("invalid username or password")
	} else if err != nil {
		return nil, err
	}
	return &customer, nil
}

func getBioskops(kota string) ([]Bioskop, error) {
	var bioskops []Bioskop
	rows, err := db.Query(`
		SELECT bioskop.id_bioskop, bioskop.nama_bioskop
		FROM bioskop
		JOIN kota ON bioskop.id_kota = kota.id_kota
		WHERE kota.nama_kota = $1
	`, kota)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	for rows.Next() {
		var bioskop Bioskop
		if err := rows.Scan(&bioskop.ID, &bioskop.NamaBioskop); err != nil {
			return nil, err
		}
		bioskops = append(bioskops, bioskop)
	}
	if err := rows.Err(); err != nil {
		return nil, err
	}
	return bioskops, nil
}

func getFilms(bioskopID string) ([]Film, error) {
	var films []Film
	rows, err := db.Query(`
		SELECT film.id_film, film.judul_film
		FROM film
		JOIN theater ON film.id_theater = theater.id_theater
		JOIN bioskop ON bioskop.id_bioskop = theater.id_bioskop
		WHERE bioskop.id_bioskop = $1
	`, bioskopID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	for rows.Next() {
		var film Film
		if err := rows.Scan(&film.ID, &film.JudulFilm); err != nil {
			return nil, err
		}
		films = append(films, film)
	}
	if err := rows.Err(); err != nil {
		return nil, err
	}
	return films, nil
}

func getTheaters(filmID string) ([]Theater, error) {
	var theaters []Theater
	rows, err := db.Query(`
		SELECT theater.id_theater, theater.theater
		FROM theater
		JOIN film ON film.id_theater = theater.id_theater
		WHERE film.id_film = $1
	`, filmID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	for rows.Next() {
		var theater Theater
		if err := rows.Scan(&theater.ID, &theater.Theater); err != nil {
			return nil, err
		}
		theaters = append(theaters, theater)
	}
	if err := rows.Err(); err != nil {
		return nil, err
	}
	return theaters, nil
}

func getSeats(theaterID string) ([]Seat, error) {
	var seats []Seat
	rows, err := db.Query(`
		SELECT seat.id_seat, seat.seat
		FROM seat
		JOIN theater ON seat.id_theater = theater.id_theater
		WHERE theater.id_theater = $1
	`, theaterID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	for rows.Next() {
		var seat Seat
		if err := rows.Scan(&seat.ID, &seat.Seat); err != nil {
			return nil, err
		}
		seats = append(seats, seat)
	}
	if err := rows.Err(); err != nil {
		return nil, err
	}
	return seats, nil
}

func insertTicketHandler(w http.ResponseWriter, r *http.Request) {
	// Parse JSON request body
	var requestBody struct {
		CustomerID int     `json:"customer_id"`
		Nominal    float64 `json:"nominal"`
		TheaterID  int     `json:"theater_id"`
	}
	if err := json.NewDecoder(r.Body).Decode(&requestBody); err != nil {
		http.Error(w, "Invalid request body", http.StatusBadRequest)
		return
	}

	// Generate a timestamp for the current time
	timestamp := time.Now().UTC()

	// Execute SQL INSERT statement to insert data into penjualan_ticket table
	_, err := db.Exec(`
		INSERT INTO penjualan_ticket (tanggal, id_customer, nominal, id_theater)
		VALUES ($1, $2, $3, $4)
	`, timestamp, requestBody.CustomerID, requestBody.Nominal, requestBody.TheaterID)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	// Retrieve the inserted row's ID from the sequence
	var lastInsertID int64
	err = db.QueryRow("SELECT currval(pg_get_serial_sequence('penjualan_ticket', 'id_penjualan'))").Scan(&lastInsertID)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	// Send response with the inserted row's ID
	response := struct {
		ID int64 `json:"id"`
	}{
		ID: lastInsertID,
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(response)
}
